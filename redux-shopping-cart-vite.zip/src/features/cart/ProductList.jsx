import React from 'react'
import { useDispatch } from 'react-redux'
import { addItem } from './cartSlice'

const products = [
  { id: 1, name: 'T-Shirt', price: 20 },
  { id: 2, name: 'Jeans', price: 50 },
  { id: 3, name: 'Shoes', price: 80 },
]

export default function ProductList() {
  const dispatch = useDispatch()
  return (
    <div>
      <h2>Products</h2>
      {products.map(p => (
        <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
          <span>{p.name} - ${p.price}</span>
          <button onClick={() => dispatch(addItem(p))}>Add to Cart</button>
        </div>
      ))}
    </div>
  )
}
