import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { removeItem, clearCart } from './cartSlice'

export default function Cart() {
  const { items, totalAmount } = useSelector(state => state.cart)
  const dispatch = useDispatch()
  return (
    <div style={{ marginTop: '20px', borderTop: '1px solid #ccc', paddingTop: '10px' }}>
      <h2>Your Cart</h2>
      {items.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        <div>
          {items.map(item => (
            <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
              <span>{item.name} x {item.quantity}</span>
              <button onClick={() => dispatch(removeItem(item.id))}>Remove</button>
            </div>
          ))}
          <p><strong>Total: ${totalAmount}</strong></p>
          <button onClick={() => dispatch(clearCart())}>Clear Cart</button>
        </div>
      )}
    </div>
  )
}
