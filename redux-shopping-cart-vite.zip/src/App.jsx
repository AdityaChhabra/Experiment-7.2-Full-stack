import React from 'react'
import Cart from './features/cart/Cart'
import ProductList from './features/cart/ProductList'

export default function App() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>🛍️ Shopping Cart</h1>
      <ProductList />
      <Cart />
    </div>
  )
}
